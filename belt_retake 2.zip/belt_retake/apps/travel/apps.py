from django.apps import AppConfig


class TripsConfig(AppConfig):
    name = 'trips'
